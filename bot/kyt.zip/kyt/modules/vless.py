from kyt import *

#delete
@bot.on(events.CallbackQuery(data=b'delete7-vless'))
async def delete_vless(event):
	async def delete_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vlg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST DELETE USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "4" "{user}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#renew
@bot.on(events.CallbackQuery(data=b'renew7-vless'))
async def renew_vless(event):
	async def renew_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vlg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST RENEW USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 Input Your New Expired (day) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "3" "{user}" "{exp}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


#limit
@bot.on(events.CallbackQuery(data=b'limit7-vless'))
async def limit_vless(event):
	async def limit_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vlg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ CHANGE LIMIT USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 Input Your New Limit IP Login :**
0 For Unlimited
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**👉 Input Your New Quota User :**
0 For Unlimited
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			cmd = f'printf "%s\n" "7" "{user}" "{exp}" "{pw}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES CHANGE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limit_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CekConfig
@bot.on(events.CallbackQuery(data=b'akun7-vless'))
async def akun_vless(event):
	async def akun_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vlg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ CEK CONFIG USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "6" "{user}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES CEK AKUN**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await akun_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
		
#restore
@bot.on(events.CallbackQuery(data=b'restore7-vless'))
async def restore_vless(event):
	async def restore_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vless/akundelete | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST AKUN RESTORE **
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 Input Your Expired (day) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**👉 Input Your New Limit IP Login :**
0 For Unlimited
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as pw2:
				await event.respond(f"""
**👉 Input Your New Quota User:**
0 For Unlimited
""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			cmd = f'printf "%s\n" "11" "{user}" "{exp}" "{pw}" "{pw2}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES CHANGE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await restore_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


#MultiLogin Login
@bot.on(events.CallbackQuery(data=b'loginip7-vless'))
async def loginip_vless(event):
	async def loginip_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vless/listlock | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST MULTI LOGIN IP USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "9" "{user}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES UNLOCK**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await loginip_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
#MultiLogin Quota
@bot.on(events.CallbackQuery(data=b'logingb7-vless'))
async def logingb_vless(event):
	async def logingb_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vless/userQuota | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST LOGIN QUOTA USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "10" "{user}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES UNLOCK**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await logingb_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
#CRATE VLESS
from telethon import Button

@bot.on(events.CallbackQuery(data=b'create7-vless'))
async def create_vless(event):
    async def create_vless_(event):
        async with bot.conversation(chat) as user_conv:
            msg_user = await event.edit("**Input UserName :**")
            user_message = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_message.raw_text
            await msg_user.delete()  # Hapus pesan UserName setelah input
        
        if user == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            return

        exp = await get_expiration(event, chat)
        if exp is None:
            return

        pw = await get_limit_ip(event, chat)
        if pw is None:
            return

        pw2 = await get_quota_user(event, chat)
        if pw2 is None:
            return

        try:
            cmd = f'printf "%s\n" "1" "{user}" "{exp}" "{pw}" "{pw2}" | m-vless | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError as e:
            await event.respond(f"**Error:** {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    async def get_expiration(event, chat):
        async with bot.conversation(chat) as exp_conv:
            buttons = [
                [Button.inline("5 hari", b'5')],
                [Button.inline("10 hari", b'10')],
                [Button.inline("15 hari", b'15')],
                [Button.inline("20 hari", b'20')],
                [Button.inline("25 hari", b'25')],
                [Button.inline("30 hari", b'30')],
                [Button.inline("Input Manual", b'manual')]
            ]
            msg_exp = await event.respond("**Input Your Expired (day)**", buttons=buttons)
            response = await exp_conv.wait_event(events.CallbackQuery)
            
            if response.data == b'manual':
                await msg_exp.delete()  # Hapus pesan tombol
                msg_manual = await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = msg_manual.raw_text
                await msg_manual.delete()  # Hapus pesan input manual
            else:
                exp = response.data.decode()  # Ambil nilai dari tombol yang ditekan
            
            await msg_exp.delete()  # Hapus pesan pilihan setelah input
            return exp

    async def get_limit_ip(event, chat):
        async with bot.conversation(chat) as pw_conv:
            buttons = [[Button.inline(str(i), str(i).encode()) for i in range(1, 11)]] + [[Button.inline("Input Manual", b'manual')]]
            msg_pw = await event.respond("**Input Your Limit IP Login**", buttons=buttons)
            
            response = await pw_conv.wait_event(events.CallbackQuery)
            
            if response.data == b'manual':
                await msg_pw.delete()  # Hapus pesan tombol
                msg_manual = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = msg_manual.raw_text
                await msg_manual.delete()  # Hapus pesan input manual
            else:
                pw = response.data.decode()  # Ambil nilai dari tombol yang ditekan
            
            await msg_pw.delete()  # Hapus pesan pilihan setelah input
            return pw

    async def get_quota_user(event, chat):
        async with bot.conversation(chat) as pw2_conv:
            msg_pw2 = await event.respond("**Input Your Quota User**\n0 For Unlimited")
            pw2_message = await pw2_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            await msg_pw2.delete()  # Hapus pesan Quota setelah input
            return pw2_message.raw_text

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# TRIAL vless
@bot.on(events.CallbackQuery(data=b'trial7-vless'))
async def trial_vless(event):
	async def trial_vless_(event):
		async with bot.conversation(chat) as exp:
			await event.edit(f"""
**👉 Input Your Timer (Minutes) :**
/cancel Kembali KeMENU
""")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		per = "/cancel"
		if exp == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" {2} "{exp}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True).decode("utf-8")
			await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CEK
@bot.on(events.CallbackQuery(data=b'cek7-vless'))
async def cek_vless(event):
	async def cek_vless_(event):
		cmd = 'bot-cek-vless'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit(f"""
**⚠️ VLESS USER ONLINE**
{z}
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vless_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'login7-vless'))
async def vless(event):
	async def vless_(event):
		inline = [
[Button.inline(" UNLOCK LOGIN ","loginip7-vless"),
Button.inline(" UNLOCK QUOTA ","logingb7-vless")],
[Button.inline("‹ Back ›","vless")]]
		await event.edit(buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
	async def vless_(event):
		inline = [
[Button.inline(" Trial ","trial7-vless"),
Button.inline(" Create ","create7-vless"),
Button.inline(" Login ","cek7-vless")],
[Button.inline(" Delete ","delete7-vless"),
Button.inline(" Unlock ","login7-vless"),
Button.inline(" Limit ","limit7-vless")],
[Button.inline(" Renew","renew7-vless"),
Button.inline(" Restore ","restore7-vless"),
Button.inline(" Akun ","akun7-vless")],
[Button.inline("‹ BACK ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		vl = f' cat /etc/xray/config.json | grep "#vlg" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		msg = f"""
🧿───────────────────🧿
                **MENU VLESS**
🧿───────────────────🧿
` Service  :` `VLESS`
` Total Acc:` `{vls.strip()}` __account__
` Host     :` `{DOMAIN}`
` ISP      :` `{z["isp"]}`
` Country  :` `{z["country"]}`
** @osproject_tuneling**
🧿───────────────────🧿
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("Access Denied",alert=True)