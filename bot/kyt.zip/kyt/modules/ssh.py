from kyt import *

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    async def create_ssh_(event):
        async with bot.conversation(chat) as user:
            # Menyimpan pesan pertama yang akan dihapus nantinya
            msg = await event.edit(f"""
**BUAT USERNAME TANPA SPASI**
""", buttons=[[Button.inline("Cancel", b'menu')]])
            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_event).raw_text

            # Menghapus pesan sebelumnya setelah input diterima
            await msg.delete()

        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            async with bot.conversation(chat) as pw:
                # Menyimpan pesan kedua
                msg_pw = await event.respond(f"""
**BUAT PASWORD AKUN**
""")
                pw_event = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = (await pw_event).raw_text

                # Menghapus pesan sebelumnya
                await msg_pw.delete()

            # Menambahkan tombol expired account
            buttons = [
                [Button.inline("10 Day", b'exp_10'), Button.inline("20 Day", b'exp_20')],
                [Button.inline("30 Day", b'exp_30'), Button.inline("40 Day", b'exp_40')],
                [Button.inline("50 Day", b'exp_50'), Button.inline("60 Day", b'exp_60')],
                [Button.inline("Manual Input", b'exp_manual')]  # Tombol untuk input manual
            ]
            
            async with bot.conversation(chat) as exp:
                # Menampilkan pesan dengan pilihan expired
                msg_exp = await event.respond(f"""
**PILIH EXPIRED AKUN ATAU MASUKKAN SECARA MANUAL**
""", buttons=buttons)

                # Menunggu pilihan dari tombol atau input manual
                exp_event = await exp.wait_event(events.CallbackQuery(data=re.compile(b'exp_')))

                if exp_event.data.decode('utf-8') == 'exp_manual':
                    # Jika pengguna memilih input manual
                    await exp_event.answer("Masukkan expired secara manual")
                    await msg_exp.delete()
                    manual_input = await exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                    exp_days = manual_input.raw_text
                else:
                    # Jika pengguna memilih dari tombol
                    exp_days = int(exp_event.data.decode('utf-8').split('_')[1])
                    await exp_event.answer(f"Expired {exp_days} days selected")
                    await msg_exp.delete()

            # Menambahkan tombol limit IP login
            ip_buttons = [
                [Button.inline(f"{i} IP", f'ip_{i}') for i in range(1, 6)],
                [Button.inline(f"{i} IP", f'ip_{i}') for i in range(6, 11)],
                [Button.inline("Manual Input", b'ip_manual')]  # Tombol untuk input manual
            ]

            async with bot.conversation(chat) as pw2:
                # Menampilkan pesan untuk limit IP login
                msg_pw2 = await event.respond(f"""
**PILIH LIMIT IP LOGIN ATAU MASUKKAN SECARA MANUAL**
""", buttons=ip_buttons)

                # Menunggu pilihan dari tombol atau input manual
                ip_event = await pw2.wait_event(events.CallbackQuery(data=re.compile(b'ip_')))

                if ip_event.data.decode('utf-8') == 'ip_manual':
                    # Jika pengguna memilih input manual untuk IP
                    await ip_event.answer("Masukkan limit IP login secara manual")
                    await msg_pw2.delete()
                    manual_input_ip = await pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                    ip_limit = manual_input_ip.raw_text
                else:
                    # Jika pengguna memilih dari tombol
                    ip_limit = int(ip_event.data.decode('utf-8').split('_')[1])
                    await ip_event.answer(f"{ip_limit} IP limit selected")
                    await msg_pw2.delete()

            # Perintah SSH yang ingin dijalankan
            cmd = f'printf "%s\n" "1" "{user}" "{pw}" "{exp_days}" "{ip_limit}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    async def delete_ssh_(event):
        async with bot.conversation(chat) as user:
            # Mendapatkan daftar semua pengguna
            cmd2 = "cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            z = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

            # Menampilkan daftar pengguna
            msg = await event.edit(f"""
**LIST ALL USER**
{z}
""", buttons=[[Button.inline("Cancel", b'menu')]])

            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = (await user_event).raw_text

            # Menghapus pesan sebelumnya setelah input diterima
            await msg.delete()

        if user_input == "/cancel":
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            # Menghapus pengguna berdasarkan input
            cmd = f'printf "%s\n" "4" "{user_input}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await delete_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cancel'))
async def cancel(event):
    await event.answer("Operasi dibatalkan.", alert=True)

@bot.on(events.CallbackQuery(data=b'limit-ssh'))
async def limit_ssh(event):
    async def limit_ssh_(event):
        async with bot.conversation(chat) as user:
            # Mendapatkan daftar semua pengguna
            cmd2 = "cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            z = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

            # Menampilkan daftar pengguna
            msg = await event.edit(f"""
**CHANGE LIMIT USER**
{z}
""", buttons=[[Button.inline("Cancel", b'cancel')]])

            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = (await user_event).raw_text

            # Menghapus pesan sebelumnya setelah input diterima
            await msg.delete()

        if user_input == "/cancel":
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            async with bot.conversation(chat) as exp:
                # Meminta limit IP login baru
                msg_exp = await event.respond(f"""
**Ketik Limit IP Login Baru :**
""")
                exp_event = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                new_limit = (await exp_event).raw_text

                # Menghapus pesan sebelumnya
                await msg_exp.delete()

            # Mengubah limit IP login pengguna
            cmd = f'printf "%s\n" "7" "{user_input}" "{new_limit}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await limit_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cancel'))
async def cancel(event):
    await event.answer("Operasi dibatalkan.", alert=True)

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    async def trial_ssh_(event):
        async with bot.conversation(chat) as exp:
            await event.edit(f"""
**Masukan Menit (Hanya angka)**
""", buttons=[[Button.inline("Cancel", b'cancel')]])

            exp_event = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            menit_input = (await exp_event).raw_text

            # Menghapus pesan sebelumnya setelah input diterima
            await event.delete()

        if menit_input == "/cancel":
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            # Mengubah trial SSH berdasarkan input menit
            cmd = f'printf "%s\n" {2} "{menit_input}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cancel'))
async def cancel(event):
    await event.answer("Operasi dibatalkan.", alert=True)

@bot.on(events.CallbackQuery(data=b'cek-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		cmd = 'bot-cek-login-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit(f"""
** SSH USER ONLINE**
{z}
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def renew_ssh(event):
    async def renew_ssh_(event):
        async with bot.conversation(chat) as user:
            # Mendapatkan daftar semua pengguna
            cmd2 = "cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            z = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

            # Menampilkan daftar pengguna
            msg = await event.edit(f"""
**LIST RENEW USER**
{z}
""", buttons=[[Button.inline("Cancel", b'cancel')]])

            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = (await user_event).raw_text

            # Menghapus pesan sebelumnya setelah input diterima
            await msg.delete()

        if user_input == "/cancel":
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            async with bot.conversation(chat) as exp:
                # Meminta expired baru
                msg_exp = await event.respond(f"""
**KETIK EXPIRED BARU (day) :**
""")
                exp_event = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                expired_input = (await exp_event).raw_text

                # Menghapus pesan sebelumnya
                await msg_exp.delete()

            # Mengubah expired SSH pengguna
            cmd = f'printf "%s\n" "3" "{user_input}" "{expired_input}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await renew_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cancel'))
async def cancel(event):
    await event.answer("Operasi dibatalkan.", alert=True)

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    async def login_ssh_(event):
        async with bot.conversation(chat) as user:
            # Mendapatkan daftar multi login user
            cmd2 = "cat /etc/xray/sshx/listlock | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            z = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

            # Menampilkan daftar multi login user
            msg = await event.edit(f"""
**LIST MULTI LOGIN USER**
{z}
""", buttons=[[Button.inline("Cancel", b'menu')]])

            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = (await user_event).raw_text

            # Menghapus pesan sebelumnya setelah input diterima
            await msg.delete()

        if user_input == "/cancel":
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            # Meng-unlock pengguna
            cmd = f'printf "%s\n" "9" "{user_input}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

            # Menghapus pesan sukses
            await event.respond(f"""
**» SUCCES UNLOCK**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await login_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cancel'))
async def cancel(event):
    await event.answer("Operasi dibatalkan.", alert=True)

@bot.on(events.CallbackQuery(data=b'akun-ssh'))
async def akun_ssh(event):
    async def akun_ssh_(event):
        async with bot.conversation(chat) as user:
            # Mendapatkan daftar pengguna
            cmd2 = "cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            z = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

            # Menampilkan daftar pengguna
            msg = await event.edit(f"""
**CEK CONFIG USER**
{z}
""", buttons=[[Button.inline("Cancel", b'menu')]])

            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = (await user_event).raw_text

            # Menghapus pesan sebelumnya setelah input diterima
            await msg.delete()

        if user_input == "/cancel":
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            # Mengecek akun
            cmd = f'printf "%s\n" "6" "{user_input}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await akun_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cancel'))
async def cancel(event):
    await event.answer("Operasi dibatalkan.", alert=True)

@bot.on(events.CallbackQuery(data=b'cancel'))
async def cancel(event):
    await event.answer("Operasi dibatalkan.", alert=True)

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline(" Trial ","trial-ssh"),
Button.inline(" Create ","create-ssh"),
Button.inline(" Login ","cek-ssh")],
[Button.inline(" Delete ","delete-ssh"),
Button.inline(" Unlock ","login-ssh"),
Button.inline(" Limit ","limit-ssh")],
[Button.inline(" Renew","renew-ssh"),
Button.inline(" Akun ","akun-ssh"),
Button.inline("‹ BACK ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f' cat /etc/xray/ssh | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		msg = f"""
🧿───────────────────🧿
               **PANEL MENU SSH**
🧿───────────────────🧿
` Total   :` `{ssh.strip()}` __account__
` Host    :` `{DOMAIN}`
` ISP     :` `{z["isp"]}`
` Country :` `{z["country"]}`
🧿───────────────────🧿
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)